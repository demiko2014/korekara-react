import { Article, getTriangle } from './App.js';

console.log(getTriangle(10, 5));

const a = new Article();
console.log(a.getAppTitle());