import Util from './Util.js';

console.log(Util.getCircleArea(10));