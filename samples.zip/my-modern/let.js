if (true) {
  let x = 13;
}
console.log(x);