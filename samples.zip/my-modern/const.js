const author = 'YAMADA.Yoshihiro';
author = 'WINGS Project';
console.log(author);