const str = null;
// console.log(str.substring(1));

// if (str !== null && str !== undefined) {
//   console.log(str.substring(1));
// }

console.log(str?.substring(1));