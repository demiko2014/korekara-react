let i = 0;
const member = {
  [`attr${++i}`]: '佐藤理央',
  [`attr${++i}`]: '女性',
  [`attr${++i}`]: '18歳'
};
console.log(member);