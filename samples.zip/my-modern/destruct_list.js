const list = [10, 20, 30];
const [x, y, z] = list;
console.log(x, y, z);

const [a, b] = list;
console.log(a, b);

const [l, m, n, o] = list;
console.log(l, m, n, o);

const [p, , r] = list;
console.log(p, r);
