import { getTriangle as tri } from './App.js';

console.log(tri(10, 2));