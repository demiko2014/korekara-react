const value = 123_456_789;
console.log(value);