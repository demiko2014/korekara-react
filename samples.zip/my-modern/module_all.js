import * as app from './App.js';

console.log(app.getTriangle(10, 2));