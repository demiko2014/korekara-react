export default class Util {
  static getCircleArea(radius) {
    return (radius ** 2) * Math.PI;
  }
}