const title = '速習React';
const price = 500;

const book = { title, price };
// const book = { title: title, price: price };

console.log(book);