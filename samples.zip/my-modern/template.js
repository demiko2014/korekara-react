const fullname = 'Taro Suzuki';
const msg = `Hello, ${fullname}
How are you today?`;
console.log(msg);