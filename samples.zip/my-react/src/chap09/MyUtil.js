export function getTriangleArea(base, height) {
  return base * height / 2;
}