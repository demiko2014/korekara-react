export default function MyLoading() {
    return (
      <p>Now Loading...</p>
    );
  }