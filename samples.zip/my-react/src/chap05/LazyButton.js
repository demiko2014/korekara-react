export default function LazyButton() {
  return (
    <div>
      <button id="btn">ボタン1</button>
    </div>
  );
}