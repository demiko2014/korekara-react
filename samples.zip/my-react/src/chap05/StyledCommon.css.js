import { css } from 'styled-components';

export default css`
  margin: 20px;
`;