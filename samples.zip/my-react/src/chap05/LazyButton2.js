export default function LazyButton2() {
  return (
    <div>
      <button id="btn">ボタン2</button>
    </div>
  );
}