export default function ArticlePage() {
  return <p>Articleページです。</p>;
}