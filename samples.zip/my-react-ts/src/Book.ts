export type Book = {
  isbn: string,
  title: string,
  price: number,
  summary: string,
  download: boolean
};